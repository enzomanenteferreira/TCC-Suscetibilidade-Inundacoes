  import Fastify from "fastify"
  import pkg from "pg"
  import axios from "axios"
  import cors from "@fastify/cors"

  const { Pool } = pkg

  const app = Fastify({ logger: true })

  // CORS (Next.js)
  await app.register(cors, {
    origin: "http://localhost:3000",
  })

  // Conexão PostGIS
  const pool = new Pool({
    host: "localhost",
    user: "postgres",
    password: "1234",
    database: "postgres",
    port: 5432,
  })

  /* =========================================================
    ROTA 1 — Consulta pontual por CEP
    ========================================================= */
  app.get("/suscetibilidade/:cep", async (req, reply) => {
    try {
      const cepLimpo = req.params.cep.replace(/\D/g, "")

      // 1. ViaCEP
      const viaCep = await axios.get(
        `https://viacep.com.br/ws/${cepLimpo}/json/`,
      )

      if (viaCep.data.erro) {
        return reply.code(400).send({ erro: "CEP inválido" })
      }

      // 2. Nominatim
      const endereco = `${viaCep.data.logradouro}, ${viaCep.data.localidade}, ${viaCep.data.uf}`

      const geo = await axios.get(
        "https://nominatim.openstreetmap.org/search",
        {
          params: {
            q: endereco,
            format: "json",
            limit: 1,
          },
          headers: {
            "User-Agent": "tcc-suscetibilidade",
          },
        },
      )

      if (geo.data.length === 0) {
        return reply
          .code(400)
          .send({ erro: "Endereço não localizado" })
      }

      const lat = parseFloat(geo.data[0].lat)
      const lon = parseFloat(geo.data[0].lon)

      // 3. Consulta raster
      const result = await pool.query(
        `
        SELECT
          ST_Value(
            rast,
            ST_Transform(
              ST_SetSRID(ST_Point($1, $2), 4326),
              31981
            )
          ) AS valor
        FROM public.raster_suscetibilidade
        WHERE ST_Intersects(
          rast,
          ST_Transform(
            ST_SetSRID(ST_Point($1, $2), 4326),
            31981
          )
        )
        LIMIT 1;
        `,
        [lon, lat],
      )

      const valor = result.rows[0]?.valor ?? null

      // Fora da área
      if (valor === null) {
        return {
          cep: cepLimpo,
          latitude: lat,
          longitude: lon,
          valor: null,
          classe: null,
          foraArea: true,
        }
      }

      // Classificação
      let classe = "Baixa"
      if (valor >= 0.66) classe = "Alta"
      else if (valor >= 0.33) classe = "Média"

      return {
        cep: cepLimpo,
        latitude: lat,
        longitude: lon,
        valor,
        classe,
        foraArea: false,
      }
    } catch (err) {
      console.error(err)
      return reply
        .code(500)
        .send({ erro: "Erro interno no servidor" })
    }
  })


  // Start
  app.listen({ port: 3001 }, () => {
    console.log("Servidor rodando em http://localhost:3001")
  })
