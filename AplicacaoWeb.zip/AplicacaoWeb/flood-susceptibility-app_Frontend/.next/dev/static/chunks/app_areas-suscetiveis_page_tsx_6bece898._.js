(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_areas-suscetiveis-map_tsx_9d51798f._.js",
  "static/chunks/_8e1e4512._.js"
],
    source: "dynamic"
});
