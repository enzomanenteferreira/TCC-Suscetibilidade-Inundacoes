(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_areas-map_tsx_b70c0ab3._.js",
  "static/chunks/node_modules_1e39a82e._.js",
  "static/chunks/_8057feb3._.js"
],
    source: "dynamic"
});
