(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_map-component_tsx_57db8827._.js",
  "static/chunks/node_modules_42effd6e._.js",
  "static/chunks/_bd1056f8._.js"
],
    source: "dynamic"
});
