(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/areas-map.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AreasMapComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/leaflet/dist/leaflet-src.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function AreasMapComponent({ areas }) {
    _s();
    const mapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AreasMapComponent.useEffect": ()=>{
            if (("TURBOPACK compile-time value", "object") === "undefined" || areas.length === 0) return;
            if (!mapRef.current) {
                const firstPoint = areas[0];
                mapRef.current = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].map("areas-map").setView([
                    firstPoint.latitude,
                    firstPoint.longitude
                ], 12);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                    attribution: "© OpenStreetMap contributors"
                }).addTo(mapRef.current);
            }
            const getColor = {
                "AreasMapComponent.useEffect.getColor": (classe)=>{
                    switch(classe){
                        case "Alta":
                            return "#ef4444";
                        case "Média":
                            return "#eab308";
                        case "Baixa":
                            return "#22c55e";
                        default:
                            return "#3b82f6";
                    }
                }
            }["AreasMapComponent.useEffect.getColor"];
            const getRadius = {
                "AreasMapComponent.useEffect.getRadius": (classe)=>{
                    switch(classe){
                        case "Alta":
                            return 10;
                        case "Média":
                            return 8;
                        case "Baixa":
                            return 6;
                        default:
                            return 6;
                    }
                }
            }["AreasMapComponent.useEffect.getRadius"];
            areas.forEach({
                "AreasMapComponent.useEffect": (area)=>{
                    const color = getColor(area.classe);
                    const radius = getRadius(area.classe);
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].circleMarker([
                        area.latitude,
                        area.longitude
                    ], {
                        radius: radius,
                        fillColor: color,
                        color: "#fff",
                        weight: 2,
                        opacity: 1,
                        fillOpacity: 0.7
                    }).bindPopup(`
          <div style="padding: 8px; min-width: 200px;">
            <h3 style="margin: 0 0 8px 0; font-weight: 600; color: ${color};">
              Suscetibilidade ${area.classe}
            </h3>
            <div style="font-size: 14px; color: #666;">
              <p style="margin: 4px 0;">
                <strong>Índice:</strong> ${Number.isFinite(area.valor) ? area.valor.toFixed(3) : "—"}
                </p>

                <p style="margin: 4px 0;">
                <strong>Lat:</strong> ${Number.isFinite(area.latitude) ? area.latitude.toFixed(6) : "—"}
                </p>

                <p style="margin: 4px 0;">
                <strong>Lon:</strong> ${Number.isFinite(area.longitude) ? area.longitude.toFixed(6) : "—"}
                </p>

            </div>
          </div>
        `, {
                        maxWidth: 250
                    }).addTo(mapRef.current);
                }
            }["AreasMapComponent.useEffect"]);
            const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].latLngBounds(areas.map({
                "AreasMapComponent.useEffect.bounds": (a)=>[
                        a.latitude,
                        a.longitude
                    ]
            }["AreasMapComponent.useEffect.bounds"]));
            mapRef.current.fitBounds(bounds, {
                padding: [
                    50,
                    50
                ]
            });
            return ({
                "AreasMapComponent.useEffect": ()=>{
                    if (mapRef.current) {
                        mapRef.current.remove();
                        mapRef.current = null;
                    }
                }
            })["AreasMapComponent.useEffect"];
        }
    }["AreasMapComponent.useEffect"], [
        areas
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "areas-map",
        className: "w-full h-full"
    }, void 0, false, {
        fileName: "[project]/components/areas-map.tsx",
        lineNumber: 117,
        columnNumber: 10
    }, this);
}
_s(AreasMapComponent, "9mn7MMe4fPaZ50ApsOpRWF2HbFg=");
_c = AreasMapComponent;
var _c;
__turbopack_context__.k.register(_c, "AreasMapComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/areas-map.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/components/areas-map.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=components_areas-map_tsx_c8ac1bc6._.js.map