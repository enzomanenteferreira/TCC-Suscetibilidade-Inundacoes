(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/heat-map-component.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeatMapComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/leaflet/dist/leaflet-src.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2e$heat$2f$dist$2f$leaflet$2d$heat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/leaflet.heat/dist/leaflet-heat.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function HeatMapComponent({ data }) {
    _s();
    const mapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mapInstanceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeatMapComponent.useEffect": ()=>{
            if (!mapRef.current || !data || mapInstanceRef.current) return;
            // Calcular centro do mapa
            const centerLat = (data.bounds.ymin + data.bounds.ymax) / 2;
            const centerLon = (data.bounds.xmin + data.bounds.xmax) / 2;
            // Inicializar mapa
            const map = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].map(mapRef.current).setView([
                centerLat,
                centerLon
            ], 12);
            mapInstanceRef.current = map;
            // Adicionar tile layer
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                maxZoom: 18
            }).addTo(map);
            // Preparar dados para heatmap com intensidade ajustada
            const heatData = data.pontos.map({
                "HeatMapComponent.useEffect.heatData": (p)=>[
                        p.lat,
                        p.lon,
                        p.valor * 1.2 // Aumenta um pouco a intensidade para melhor visualização
                    ]
            }["HeatMapComponent.useEffect.heatData"]);
            // Camada de calor com configurações otimizadas
            const heat = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].heatLayer(heatData, {
                radius: 30,
                blur: 25,
                maxZoom: 15,
                max: 1.0,
                minOpacity: 0.4,
                gradient: {
                    0.0: "#00ff00",
                    0.2: "#7fff00",
                    0.35: "#ffff00",
                    0.5: "#ffcc00",
                    0.65: "#ff9900",
                    0.8: "#ff4500",
                    1.0: "#cc0000" // Vermelho escuro (alta)
                }
            }).addTo(map);
            // Ajustar bounds
            const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].latLngBounds([
                data.bounds.ymin,
                data.bounds.xmin
            ], [
                data.bounds.ymax,
                data.bounds.xmax
            ]);
            map.fitBounds(bounds, {
                padding: [
                    50,
                    50
                ]
            });
            // Adicionar contornos para áreas de ALTO risco (≥ 0.7)
            const highRiskAreas = data.pontos.filter({
                "HeatMapComponent.useEffect.highRiskAreas": (p)=>p.valor >= 0.7
            }["HeatMapComponent.useEffect.highRiskAreas"]);
            // Agrupar pontos próximos para criar zonas
            const riskZones = new Map();
            highRiskAreas.forEach({
                "HeatMapComponent.useEffect": (point)=>{
                    const key = `${Math.round(point.lat * 100)}_${Math.round(point.lon * 100)}`;
                    if (!riskZones.has(key)) {
                        riskZones.set(key, {
                            lat: point.lat,
                            lon: point.lon,
                            maxValor: point.valor,
                            count: 1
                        });
                    } else {
                        const zone = riskZones.get(key);
                        zone.maxValor = Math.max(zone.maxValor, point.valor);
                        zone.count++;
                    }
                }
            }["HeatMapComponent.useEffect"]);
            // Desenhar zonas de alto risco
            riskZones.forEach({
                "HeatMapComponent.useEffect": (zone)=>{
                    if (zone.count >= 2) {
                        const circle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].circle([
                            zone.lat,
                            zone.lon
                        ], {
                            radius: 300,
                            color: zone.maxValor >= 0.85 ? '#cc0000' : '#ff6600',
                            fillColor: zone.maxValor >= 0.85 ? '#cc0000' : '#ff6600',
                            fillOpacity: 0.15,
                            weight: 2,
                            opacity: 0.6,
                            dashArray: '5, 5'
                        }).addTo(map);
                        circle.bindTooltip(`
          <strong>Zona de ${zone.maxValor >= 0.85 ? 'Risco Crítico' : 'Alto Risco'}</strong><br/>
          Índice máximo: ${zone.maxValor.toFixed(3)}<br/>
          ${zone.count} pontos concentrados
        `, {
                            permanent: false,
                            direction: 'top'
                        });
                    }
                }
            }["HeatMapComponent.useEffect"]);
            // Adicionar marcadores APENAS para pontos críticos (≥ 0.85)
            const criticalPoints = data.pontos.filter({
                "HeatMapComponent.useEffect.criticalPoints": (p)=>p.valor >= 0.85
            }["HeatMapComponent.useEffect.criticalPoints"]);
            criticalPoints.forEach({
                "HeatMapComponent.useEffect": (point)=>{
                    const marker = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].circleMarker([
                        point.lat,
                        point.lon
                    ], {
                        radius: 7,
                        fillColor: "#8b0000",
                        color: "#ffffff",
                        weight: 2,
                        opacity: 1,
                        fillOpacity: 0.9
                    }).addTo(map);
                    marker.bindPopup(`
        <div style="font-family: sans-serif; min-width: 200px;">
          <div style="background: #8b0000; color: white; padding: 8px; margin: -10px -10px 10px -10px; border-radius: 4px 4px 0 0;">
            <strong>⚠️ RISCO CRÍTICO</strong>
          </div>
          <div style="padding: 5px 0;">
            <strong>Índice:</strong> ${point.valor.toFixed(3)}<br/>
            <strong>Classificação:</strong> Muito Alta<br/>
            <small style="color: #666;">
              Lat: ${point.lat.toFixed(6)}<br/>
              Lon: ${point.lon.toFixed(6)}
            </small>
          </div>
        </div>
      `);
                }
            }["HeatMapComponent.useEffect"]);
            // Adicionar legenda personalizada no mapa
            const legend = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].control({
                position: 'bottomright'
            });
            legend.onAdd = ({
                "HeatMapComponent.useEffect": function() {
                    const div = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].DomUtil.create('div', 'info legend');
                    div.style.background = 'white';
                    div.style.padding = '10px';
                    div.style.borderRadius = '5px';
                    div.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';
                    const grades = [
                        0,
                        0.33,
                        0.66,
                        0.85
                    ];
                    const labels = [
                        'Baixa',
                        'Média',
                        'Alta',
                        'Crítica'
                    ];
                    const colors = [
                        '#00ff00',
                        '#ffff00',
                        '#ff9900',
                        '#cc0000'
                    ];
                    div.innerHTML = '<strong style="display: block; margin-bottom: 8px;">Suscetibilidade</strong>';
                    for(let i = 0; i < grades.length; i++){
                        div.innerHTML += '<div style="margin: 5px 0;">' + '<i style="background:' + colors[i] + '; width: 18px; height: 18px; display: inline-block; margin-right: 8px; border-radius: 2px;"></i> ' + labels[i] + ' (' + grades[i].toFixed(2) + '+)' + '</div>';
                    }
                    div.innerHTML += `<hr style="margin: 8px 0;"><small>${data.total} pontos analisados</small>`;
                    return div;
                }
            })["HeatMapComponent.useEffect"];
            legend.addTo(map);
            // Cleanup
            return ({
                "HeatMapComponent.useEffect": ()=>{
                    if (mapInstanceRef.current) {
                        mapInstanceRef.current.remove();
                        mapInstanceRef.current = null;
                    }
                }
            })["HeatMapComponent.useEffect"];
        }
    }["HeatMapComponent.useEffect"], [
        data
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: mapRef,
        className: "w-full h-full"
    }, void 0, false, {
        fileName: "[project]/components/heat-map-component.tsx",
        lineNumber: 177,
        columnNumber: 10
    }, this);
}
_s(HeatMapComponent, "HGOaeZ8o3YxgkGMPZTdc6qMIX/A=");
_c = HeatMapComponent;
var _c;
__turbopack_context__.k.register(_c, "HeatMapComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/heat-map-component.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/components/heat-map-component.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=components_heat-map-component_tsx_0334ef87._.js.map