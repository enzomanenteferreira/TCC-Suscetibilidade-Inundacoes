(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_leaflet_dist_leaflet_ef5f0413.css",
  "static/chunks/node_modules_leaflet_dist_leaflet-src_a04bdcaf.js",
  "static/chunks/components_map-component_tsx_e6a66e48._.js"
],
    source: "dynamic"
});
