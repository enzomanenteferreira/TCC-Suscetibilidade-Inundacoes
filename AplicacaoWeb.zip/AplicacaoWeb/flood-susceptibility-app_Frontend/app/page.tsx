"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { MapPin, Droplets, AlertTriangle, Loader2, Map } from "lucide-react"
import dynamic from "next/dynamic"
import Link from "next/link"

const MapComponent = dynamic(() => import("@/components/map-component"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center bg-muted">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  ),
})

interface ResultData {
  cep: string
  latitude: number
  longitude: number
  valor: number | null
  classe: "Baixa" | "Média" | "Alta" | null
  foraArea: boolean
}

export default function Home() {
  const [cep, setCep] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ResultData | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleConsultar = async () => {
    if (!cep) {
      setError("Por favor, digite um CEP")
      return
    }

    const cepLimpo = cep.replace(/\D/g, "")
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const res = await fetch(`http://localhost:3001/suscetibilidade/${cepLimpo}`)
      const data = await res.json()

      if (!res.ok || data.erro) {
        setError(data.erro || "Erro na consulta")
      } else {
        setResult(data)
      }
    } catch {
      setError("Erro ao consultar o CEP. Verifique sua conexão.")
    } finally {
      setLoading(false)
    }
  }

  const getClasseColor = (classe: string | null) => {
    switch (classe) {
      case "Alta":
        return "text-risk-high"
      case "Média":
        return "text-risk-medium"
      case "Baixa":
        return "text-risk-low"
      default:
        return "text-foreground"
    }
  }

  const getClasseBgColor = (classe: string | null) => {
    switch (classe) {
      case "Alta":
        return "bg-risk-high/10 border-risk-high"
      case "Média":
        return "bg-risk-medium/10 border-risk-medium"
      case "Baixa":
        return "bg-risk-low/10 border-risk-low"
      default:
        return "bg-muted border-border"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-cyan-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Droplets className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold text-foreground">Análise de Suscetibilidade a Inundações/Alagamentos</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-[400px_1fr] gap-6">
          {/* Painel de Consulta */}
          <div className="space-y-6">
            {/* Hero Section */}
            <Card className="p-6 bg-gradient-to-br from-blue-600 to-cyan-600 text-white border-0">
              <div className="flex items-start gap-3 mb-4">
                <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                  <AlertTriangle className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-2">Consulta de Risco</h2>
                  <p className="text-blue-50 text-sm">Verifique o nível de suscetibilidade a inundações do seu CEP</p>
                </div>
              </div>
            </Card>

            {/* Formulário de Consulta */}
            <Card className="p-6">
              <div className="space-y-4">
                <div>
                  <label htmlFor="cep" className="text-sm font-medium mb-2 block">
                    Digite o CEP
                  </label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="cep"
                        type="text"
                        placeholder="00000-000"
                        value={cep}
                        onChange={(e) => setCep(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && handleConsultar()}
                        className="pl-9"
                        maxLength={9}
                      />
                    </div>
                    <Button onClick={handleConsultar} disabled={loading} className="bg-blue-600 hover:bg-blue-700">
                      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Consultar"}
                    </Button>
                  </div>
                </div>

                {error && (
                  <div className="p-4 bg-destructive/10 border border-destructive rounded-lg">
                    <p className="text-sm text-destructive font-medium">{error}</p>
                  </div>
                )}

                {result && (
                  <div className="space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="p-4 bg-muted rounded-lg space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">CEP:</span>
                        <span className="font-mono font-medium">{result.cep}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Coordenadas:</span>
                        <span className="font-mono text-sm">
                          {result.latitude.toFixed(4)}, {result.longitude.toFixed(4)}
                        </span>
                      </div>
                    </div>

                    {result.foraArea ? (
                      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                        <p className="text-sm text-amber-800 font-medium">⚠️ Este local está fora da área de análise</p>
                      </div>
                    ) : (
                      <div className={`p-4 border-2 rounded-lg ${getClasseBgColor(result.classe)}`}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">Nível de Risco:</span>
                          <span className={`text-2xl font-bold ${getClasseColor(result.classe)}`}>{result.classe}</span>
                        </div>
                        {result.valor !== null && (
                          <div className="text-sm text-muted-foreground">
                            Valor de suscetibilidade: {result.valor.toFixed(2)}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </Card>

            {/* Legenda */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Map className="h-4 w-4" />
                Legenda de Risco
              </h3>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded bg-risk-low" />
                  <span className="text-sm">Baixa Suscetibilidade</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded bg-risk-medium" />
                  <span className="text-sm">Média Suscetibilidade</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded bg-risk-high" />
                  <span className="text-sm">Alta Suscetibilidade</span>
                </div>
              </div>
            </Card>
          </div>

          <Card className="p-0 overflow-hidden shadow-xl">
            <div className="h-[800px] w-full">
              <MapComponent latitude={result?.latitude} longitude={result?.longitude} />
            </div>
          </Card>
        </div>
      </main>
    </div>
  )
}
