"use client"

import { useEffect, useRef } from "react"
import "leaflet/dist/leaflet.css"

interface MapComponentProps {
  latitude?: number
  longitude?: number
}

export default function MapComponent({ latitude, longitude }: MapComponentProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const markerRef = useRef<any>(null)

  useEffect(() => {
    if (typeof window === "undefined" || !mapRef.current) return

    const initMap = async () => {
      const L = (await import("leaflet")).default

      // Fix para ícones do Leaflet
      delete (L.Icon.Default.prototype as any)._getIconUrl
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
        iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
        shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      })

      if (!mapInstanceRef.current) {
        // Criar mapa centralizado no Brasil
        const map = L.map(mapRef.current, {
          center: [-25.5469, -54.5882],
          zoom: 12,
          zoomControl: true,
        })

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
          maxZoom: 19,
        }).addTo(map)

        mapInstanceRef.current = map
      }
    }

    initMap()

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [])

  useEffect(() => {
    if (!mapInstanceRef.current || !latitude || !longitude) return

    const updateMarker = async () => {
      const L = (await import("leaflet")).default

      // Remove marcador anterior
      if (markerRef.current) {
        markerRef.current.remove()
      }

      // Adiciona novo marcador
      const marker = L.marker([latitude, longitude]).addTo(mapInstanceRef.current)
      marker.bindPopup(`<b>Localização Consultada</b><br>Lat: ${latitude.toFixed(4)}<br>Lng: ${longitude.toFixed(4)}`)
      markerRef.current = marker

      // Centraliza no marcador
      mapInstanceRef.current.setView([latitude, longitude], 15)
    }

    updateMarker()
  }, [latitude, longitude])

  return <div ref={mapRef} className="w-full h-full" />
}
